function MyLandWindow(){
	var self=Ti.UI.createWindow({
		barImage:Ti.App.ResourcePath + L('top_bar'),
		navBarHidden:false,
		title:'My Land',
		backgroundColor:Ti.App.DefaultBackGroundColor
	});
	
	return self;
};
module.exports = MyLandWindow;
