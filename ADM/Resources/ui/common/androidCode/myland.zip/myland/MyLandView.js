function MyLandView(level, areaname,zoneName){
	var self = Ti.UI.createView({
		top:10,
		left:0,
		right:0
	});
	
	//alert(level);
	// ############ MY LAND TOP TAB BAR LIKE UI ################# //
	
	 var Toptab_View = require(Ti.App.ClassPath + L('toptab_myland'));
	 var Toptab_View = new Toptab_View(level, areaname, zoneName);
	 self.add(Toptab_View);
		
	// ##########  LISTING OF ALL VIEWS IN TAB ################ //
	var section = Ti.UI.createListSection();
	
	//alert(get_id);
	// var webserviceLand = require(Ti.App.ClassPath + L('webserviceLand'));
	// var webserviceLand = new webserviceLand();
	// Ti.API.info(webserviceLand);
	// self.add(Toptab_View);
	var HttpManager = require(L('HttpManager'));
	var httpManager = new HttpManager();
	
	if(level == 0)
    {
		var	httpManager = httpManager.webserviceMyland(function(e) { 
				curentItem = e; 
				show_Myland();
			});
		function show_Myland()
		{
			 //alert(curentItem.length); alert(curentItem.length);
			 var sections = [];
			        for(var i=0;i<curentItem.length; i++)
					{
						 sections.push({
					       template:'template',
					       title: {text:curentItem.item(i).text},
					       properties : {
					            itemId:curentItem.item(i).text,
					            accessoryType: Ti.UI.LIST_ACCESSORY_TYPE_NONE
					        }
					    });
					}
			
		   section.setItems(sections);
		    var listView_land = Ti.UI.createListView({
		  	sections: [section],
		  	top : GetHeight(50),
		  	left:GetWidth(10),
		    right:GetWidth(10),
		    templates: { 'template': Ti.App.ExpandCollapseTemplate },
		    defaultItemTemplate: 'template',
		    backgroundColor:Ti.App.DefaultBackGroundColor
		    });
			self.add(listView_land);
			
			listView_land.addEventListener('itemclick', function(e) {
		
						var item = e.section.getItemAt(e.itemIndex);
						Ti.API.info('Clicked row property : ' + item.properties.itemId); //alert(item.properties.itemId);
						
						Ti.App.areaname = item.properties.itemId;
						
						self.fireEvent('listItemSelected', {
							        module : 'zoneSelect',
							        areaname : item.properties.itemId,
									itemid : item.properties.itemId,
									id : e.itemIndex
						});
			});		
		}
		
			
	}
	else if(level == 1)	
	{
		var	httpManager = httpManager.webserviceMyzone(areaname, function(e) { //alert(e.length);
				curentItem = e;
				show_Myzone();
			});	
		function show_Myzone()
		{
			 var sections = [];
			        for(var i=0;i<curentItem.length; i++)
					{
						 sections.push({
					       template:'template',
					       title: {text:curentItem.item(i).text},
					       properties : {
					            itemId: curentItem.item(i).text,
					            accessoryType: Ti.UI.LIST_ACCESSORY_TYPE_NONE
					        }
					    });
					}
			
		   section.setItems(sections);
		   var listView_zone = Ti.UI.createListView({
		  	sections: [section],
		  	top : GetHeight(50),
		  	left:GetWidth(10),
		    right:GetWidth(10),
		    templates: { 'template': Ti.App.ExpandCollapseTemplate },
		    defaultItemTemplate: 'template',
		    backgroundColor:Ti.App.DefaultBackGroundColor
		    });
			self.add(listView_zone);
			
			listView_zone.addEventListener('itemclick', function(e) {
		
						var item = e.section.getItemAt(e.itemIndex);
						Ti.API.info('Clicked row property : ' + item.properties.itemId); //alert(item.properties.itemId);
						
						Ti.App.zoneName = item.properties.itemId;
						
						self.fireEvent('listItemSelected', {
							        module : 'sectorSelect',
									zoneName : item.properties.itemId,
									areaname : areaname,
									itemid : item.properties.itemId,
									id : e.itemIndex
						});
			});	
		}
		
	}	
	else if(level == 2)	
	{
		var	httpManager = httpManager.webserviceMyplot(zoneName,function(e) {
				curentItem = e;
				show_Myplot();
			});	
		function show_Myplot()
		{
			 var sections = [];
			        for(var i=0;i<curentItem.length; i++)
					{
						 sections.push({
					       template:'template',
					       title: {text:curentItem.item(i).text},
					       properties : {
					            itemId: curentItem.item(i).text,
					            accessoryType: Ti.UI.LIST_ACCESSORY_TYPE_NONE
					        }
					    });
					}
			
		   section.setItems(sections);
		   
		   var listView_plot = Ti.UI.createListView({
		  	sections: [section],
		  	top : GetHeight(50),
		  	left:GetWidth(10),
		    right:GetWidth(10),
		    templates: { 'template': Ti.App.ExpandCollapseTemplate },
		    defaultItemTemplate: 'template',
		    backgroundColor:Ti.App.DefaultBackGroundColor
		    });
			self.add(listView_plot);
			
				listView_plot.addEventListener('itemclick', function(e) {
			
							var item = e.section.getItemAt(e.itemIndex);
							Ti.API.info('Clicked row property : ' + item.properties.itemId); //alert(item.properties.itemId);
							
								Ti.App.plotName = item.properties.itemId;
							
							self.fireEvent('listItemSelected', {
					        module : 'plotSelected',
							plotName : item.properties.itemId,
							zoneName : zoneName,
							areaname : areaname,
							itemid : item.properties.itemId,
							id : e.itemIndex
				         });
			});	
		}	
	}	
		

	
	return self;
	
};
module.exports = MyLandView;