function Mymapwindow(){
	var self=Ti.UI.createWindow({
		barImage:Ti.App.ResourcePath + L('top_bar'),
		navBarHidden:false,
		title:'My Land',
		backgroundColor:Ti.App.DefaultBackGroundColor
	});
	
	
	 // alert(Ti.App.areaname +' - ' + Ti.App.zoneName + ' - '+ Ti.App.plotName); alert('set');
	  
	 var self_view = Ti.UI.createView({
		top:0,
		width:'100%',
		left:0,
		//layout:'vertical'
	 });
	
// ####### AREA VIEW ########### //
   var MymapView = 	Ti.UI.createView({
		top:0,
		backgroundColor:'#f3f5eb',
		width:'100%',
		height:GetHeight(40),
		left:GetWidth(7),
		//borderColor:'red',
		layout:'Horizontal'
	});
	self_view.add(MymapView);
	
	var twotabView = Ti.UI.createView({
		top:GetHeight(5),
		
		width:GetWidth(300),
		height:GetHeight(30),
		borderColor:'#8a2008',
		borderRadius:5,
		borderWidth:1,
		layout:'Horizontal'
		//left:GetWidth(10),
	});
	MymapView.add(twotabView);
	
	var Map_Tab = Ti.UI.createLabel({
					text : 'Map',
					
					font : {
						fontSize : GetWidth(12),
						fontWeight : "bold",
					},
					color : '#000',
					textAlign:'center',
					width:GetWidth(150),
					height:GetHeight(30)
				});
	twotabView.add(Map_Tab);
	
	var Detail_Tab = Ti.UI.createLabel({
					text : 'Details',
					backgroundColor:'#8a1d04',
					font : {
						fontSize : GetWidth(12),
						fontWeight : "bold",
					},
					color : '#000',
					textAlign:'center',
					width:GetWidth(150),
					height:GetHeight(30)
				});
	twotabView.add(Detail_Tab);
	
	var detailView ;
	
	var mapView;
	
	var detailView = details_show_View(detailView);
	
	self_view.add(detailView);
	
	detailView.show();
	
	var mapView = map_show_View(mapView);
	
	self_view.add(mapView);
	
	mapView.hide();
	
	Map_Tab.addEventListener('click',function(e){

		mapView.show()
	    
	    detailView.hide();
	    
	    Map_Tab.color = '#FFFFFF';
	    Detail_Tab.color = '#000000';
	    
	    Detail_Tab.backgroundColor ='#f3f5eb';
	    Map_Tab.backgroundColor ='#8a1d04';
	});	
	
	
	Detail_Tab.addEventListener('click',function(e){
		
		mapView.hide()
	    
	    detailView.show();
	    
	    Map_Tab.color = '#000000';
	    Detail_Tab.color = '#FFFFFF';
	    
	    Map_Tab.backgroundColor ='#f3f5eb';
	    Detail_Tab.backgroundColor ='#8a1d04';
	});	

// #############   FUNCTION FOR BOTH DETAILS VIEW AND MAP VIEW ############# //	
	function map_show_View(mapView)
	{
			  mapView = Ti.UI.createView({
					top:GetHeight(35),
					left:GetWidth(7),
					//borderColor:'red',
					//layout:'Horizontal'	
		            });
		            
		         var webview_map = Titanium.UI.createWebView({url:'http://www.arcgis.com/home/webmap/viewer.html?url=http://gis.adm.gov.ae/sddgisms/rest/services/MyLand_ZoneSectorPlot/MapServer?layers=show:0,1,2',
		              top:GetHeight(45)});
		         
	              mapView.add(webview_map);      
		            
		      return  mapView;     
	}
// #############   FUNCTION FOR BOTH DETAILS VIEW AND MAP VIEW ############# //	
	function details_show_View(detailView)
	{
		  detailView = Ti.UI.createView({
					top:GetHeight(35),
					left:GetWidth(7),
					//borderColor:'red',
					//layout:'Horizontal'	
		            });
		            
		var  content_view = Ti.UI.createView({
					top:GetHeight(20),
					left:GetWidth(7),
					//borderColor:'red',
					layout:'vertical'	
		            }); 
		            
		detailView.add(content_view);                     
		            
		var areaName = Ti.UI.createLabel({
					text : 'Area Name',
					top:GetHeight(5),
					font : {
						fontSize : GetWidth(12),
						fontWeight : "bold",
					},
					color : '#999999',
					textAlign:'left',
					width:'90%'
				});
	     content_view.add(areaName); 
	     
	     var areaName_val = Ti.UI.createLabel({
					text : Ti.App.areaname,
					top:GetHeight(5),
					font : {
						fontSize : GetWidth(12),
						fontWeight : "bold",
					},
					color : '#666666',
					textAlign:'left',
					width:'90%'
				});
	     content_view.add(areaName_val);  
	     
	     var zoneName = Ti.UI.createLabel({
					text : 'Zone Name',
					top:GetHeight(10),
					font : {
						fontSize : GetWidth(12),
						fontWeight : "bold",
					},
					color : '#999999',
					textAlign:'left',
					width:'90%'
				});
	     content_view.add(zoneName); 
	     
	     var zoneName_val = Ti.UI.createLabel({
					text : Ti.App.zoneName,
					top:GetHeight(5),
					font : {
						fontSize : GetWidth(12),
						fontWeight : "bold",
					},
					color : '#666666',
					textAlign:'left',
					width:'90%'
				});
	     content_view.add(zoneName_val); 
	     
	     var plotnumber = Ti.UI.createLabel({
					text : 'Zone Name',
					top:GetHeight(10),
					font : {
						fontSize : GetWidth(12),
						fontWeight : "bold",
					},
					color : '#999999',
					textAlign:'left',
					width:'90%'
				});
	     content_view.add(plotnumber); 
	     
	     var plotnumber_val = Ti.UI.createLabel({
					text : Ti.App.plotName,
					top:GetHeight(5),
					font : {
						fontSize : GetWidth(12),
						fontWeight : "bold",
					},
					color : '#666666',
					textAlign:'left',
					width:'90%'
				});
	     content_view.add(plotnumber_val);           
		
		return detailView;
	}
	
	self.add(self_view);
	
	return self;
};
module.exports = Mymapwindow;
