function FindUsView(){
	var self=Ti.UI.createView({
		top:0,
		left:0
	});
	
	return self;
};
module.exports = FindUsView;
